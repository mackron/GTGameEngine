-- This is default config for examples. Can also be used as a template for other projects.
Directories =
{
    Data = "data"
}

Shaders =
{
    "shaders/engine/glsl";
    "shaders/glsl";
}
