-- Copyright (C) 2011 - 2013 David Reid. See included LICENCE file.

function GTGUI.Element:CrossButton()
    return self;
end