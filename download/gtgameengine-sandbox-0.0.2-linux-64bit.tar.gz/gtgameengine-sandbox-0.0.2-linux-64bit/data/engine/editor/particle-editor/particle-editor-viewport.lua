-- Copyright (C) 2011 - 2013 David Reid. See included LICENCE file.

function GTGUI.Element:ParticleEditorViewport()
    self:DefaultEditor3DViewport();
    
    return self;
end