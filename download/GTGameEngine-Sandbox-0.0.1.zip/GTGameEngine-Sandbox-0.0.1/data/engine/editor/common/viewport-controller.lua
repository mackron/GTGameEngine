-- Copyright (C) 2011 - 2013 David Reid. See included LICENCE file.

GTEngine.ViewportController = {}
GTEngine.ViewportController.__index = GTEngine.ViewportController;

function GTEngine.ViewportController.Create(ownerElement)
    local new = {}
    setmetatable(new, GTEngine.ViewportController);
        new.OwnerElement = ownerElement;
        new.Callbacks    = GTCore.CallbackManager:Create();
    return new;
end

function GTEngine.ViewportController:Delete()
    self:ClearEvents();
end


function GTEngine.ViewportController:Reset()
    self.Callbacks:ClearAll();
end


function GTEngine.ViewportController:OnMouseEnter(data)
    self.Callbacks:BindOrCall("OnMouseEnter", data);
end

function GTEngine.ViewportController:OnMouseLeave(data)
    self.Callbacks:BindOrCall("OnMouseLeave", data);
end


function GTEngine.ViewportController:OnLMBDown(data)
    self.Callbacks:BindOrCall("OnLMBDown", data);
end

function GTEngine.ViewportController:OnRMBDown(data)
    self.Callbacks:BindOrCall("OnRMBDown", data);
end

function GTEngine.ViewportController:OnMMBDown(data)
    self.Callbacks:BindOrCall("OnMMBDown", data);
end


function GTEngine.ViewportController:OnLMBUp(data)
    self.Callbacks:BindOrCall("OnLMBUp", data);
end

function GTEngine.ViewportController:OnRMBUp(data)
    self.Callbacks:BindOrCall("OnRMBUp", data);
end

function GTEngine.ViewportController:OnMMBUp(data)
    self.Callbacks:BindOrCall("OnMMBUp", data);
end






function GTEngine.ViewportController:Default()
    self:Reset();

    self.IsMouseOver     = false;
    self.IsLMBDown       = false;
    self.IsRMBDown       = false;
    self.IsMMBDown       = false;
    self.HasMouseCapture = false;
    
    
    self.BaseReset = self.Reset;
    function self:Reset()
        self:BaseReset();
        
        if self.HasMouseCapture then
            Game.ReleaseMouse();
        end
    end
    
    
    
    self:OnMouseEnter(function(data)
        self.IsMouseOver = true;
    end);
    
    self:OnMouseLeave(function(data)
        self.IsMouseOver = false;
    end);
    
    
    self:OnLMBDown(function(data)
        self.IsLMBDown = true;
        self.OwnerElement:Focus();
        
        if not Game.IsMouseCaptured() then
            Game.CaptureMouse();
            self.HasMouseCapture = true;
        end
    end);
    
    self:OnRMBDown(function(data)
        self.IsRMBDown = true;
        self.OwnerElement:Focus();
        
        if not Game.IsMouseCaptured() then
            Game.CaptureMouse();
            self.HasMouseCapture = true;
        end
    end);
    
    self:OnMMBDown(function(data)
        self.IsMMBDown = true;
        self.OwnerElement:Focus();
        
        if not Game.IsMouseCaptured() then
            Game.CaptureMouse();
            self.HasMouseCapture = true;
        end
    end);
    
    
    self:OnLMBUp(function(data)
        self.IsLMBDown = false;
        
        if not GTGUI.Server.IsRMBDown() and not GTGUI.Server.IsMMBDown() then
            Game.ReleaseMouse();
            self.HasMouseCapture = false;
        end
    end);
    
    self:OnRMBUp(function(data)
        self.IsRMBDown = false;
        
        if not GTGUI.Server.IsLMBDown() and not GTGUI.Server.IsMMBDown() then
            Game.ReleaseMouse();
            self.HasMouseCapture = false;
        end
    end);
    
    self:OnMMBUp(function(data)
        self.IsMMBDown = false;
        
        if not GTGUI.Server.IsLMBDown() and not GTGUI.Server.IsRMBDown() then
            Game.ReleaseMouse();
            self.HasMouseCapture = false;
        end
    end);
end

























