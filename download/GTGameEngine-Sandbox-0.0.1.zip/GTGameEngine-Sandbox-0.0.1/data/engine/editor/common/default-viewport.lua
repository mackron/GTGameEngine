-- Copyright (C) 2011 - 2013 David Reid. See included LICENCE file.

function GTGUI.Element:DefaultViewport()
    self.CameraNode             = GTEngine.SceneNode:Create();
    self.CameraComponent        = self.CameraNode:AddComponent(GTEngine.Components.Camera);
    
    self.Controller             = GTEngine.ViewportController.Create(self.CameraNode);
    self.HasMouseCapture        = false;
    self.HandlingMouseDownEvent = false;
    
    
    
    
    
    Game.OnMouseCaptured(function(data)
        if self.HandlingMouseDownEvent then
            self.HasMouseCapture = true;
        end
    end);
    
    Game.OnMouseReleased(function(data)
        self.HasMouseCapture = false;
    end);
    
    

    
    self:OnMouseEnter(function(data)
        if self.Controller then self.Controller:OnMouseEnter() end;
    end);
    
    self:OnMouseLeave(function(data)
        if self.Controller then self.Controller:OnMouseLeave() end;
    end);
    

    
    self:WatchLMBDown(function(data)
        if data.receiver == self then
            if self.Controller then
                self.Controller:OnLMBDown();
            end
        end
    end);
    
    self:WatchRMBDown(function(data)
        if data.receiver == self then
            if self.Controller then
                self.Controller:OnRMBDown();
            end
        end
    end);
    
    self:WatchMMBDown(function(data)
        if data.receiver == self then
            if self.Controller then
                self.Controller:OnMMBDown();
            end
        end
    end);
    
    
    self:WatchLMBUp(function(data)
        if data.receiver == self or self.HasMouseCapture then
            if self.Controller then
                self.Controller:OnLMBUp();
            end
        end
    end);
    
    self:WatchRMBUp(function(data)
        if data.receiver == self or self.HasMouseCapture then
            if self.Controller then
                self.Controller:OnRMBUp();
            end
        end
    end);
    
    self:WatchMMBUp(function(data)
        if data.receiver == self or self.HasMouseCapture then
            if self.Controller then
                self.Controller:OnMMBUp();
            end
        end
    end);
    
    
    return self;
end