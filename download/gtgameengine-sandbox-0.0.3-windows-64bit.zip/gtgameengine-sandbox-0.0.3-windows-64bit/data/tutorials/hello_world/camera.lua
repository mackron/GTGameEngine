function self:OnStartup()
    self.Scene:SetViewportCamera(self);
end