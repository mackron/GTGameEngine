-- Copyright (C) 2011 - 2013 David Reid. See included LICENCE file.

function GTGUI.Element:ImageEditor(_internalPtr)
    self:SubEditor(_internalPtr);
    
    return self;
end