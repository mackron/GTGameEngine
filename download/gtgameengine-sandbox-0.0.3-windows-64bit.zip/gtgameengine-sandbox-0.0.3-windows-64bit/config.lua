-- This is default config for examples. Can also be used as a template for other projects.

Directories.Data[1] = "data"
